//
//  Ticket.hpp
//  ms3
//
//  Created by Dhruv  on 2020-11-29.
//

#ifndef Ticket_hpp
#define Ticket_hpp

#include <stdio.h>

#endif /* Ticket_hpp */
